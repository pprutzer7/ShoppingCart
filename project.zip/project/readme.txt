Shopping cart app

1. Make certain that all .jpg files and .txt files
are in the same directory folder as project.jar

2. Double click project.jar

3. To log in as seller enter credentials
username: merchant
password: merch777
there is only one seller account

4. To log in as buyer either enter previously
used credentials or click the make a new account
button in the top right corner of the login 
window and create a set of credentials.