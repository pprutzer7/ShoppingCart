package controllers;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import models.Product;
import models.User;


 // Return the division of 2 Complex numbers.
 // @precondition z.real()!=0 && z.imag()!=0 (or !z.equals(new Complex(0)))
 // @postcondition return the division of this and another complex number
 // @param z the second operand.
 // @return the division 
 

/**
 * @author phil
 * This is the controller class. It is meant to keep track of current status of shopping cart and inventory and cost revenue profits
 * there is to be only one instance of the controller class which is done by having it initialized as a static object
 * It has an arraylist of products which holds the current state of inventory and an arraylist of users which holds the 
 * current status of each user and each user object has a shopping cart, the shopping cart for the activeuser which is a
 * memnber variable of the controller holds the status of the currently logged in users shopping cart
 */
public class Controller {
	
	public ArrayList<Product> inventory;
	public ArrayList<User> users;
	public User ActiveUser;
	public double cost;
	public double revenue;
	public double profit;
	
	
	/**
	 * initializes inventory to an empty arraylist of Product objects and
	 * users to an empty arraylist of User objects
	 */
	public Controller(){
		inventory = new ArrayList<Product>();
		users = new ArrayList<User>();
	}
	
	
	/**
	 * Check login credentials and return user id if valid
	 * @precondition un not null and pwd not null
	 * @postcondition return user id of user if credentials match an entry in 'credentials.txt'
	 * or return user id of 0 if credentials are not in the text doc
	 * @param un username from text entry box
	 * @param pwd password from text entry box
	 * @return valid user id or 0 if credentials are invalid
	 */
	public int checkCredentials(String un, String pwd){
		int uid = 0;
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("credentials.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            while (s != null) {
                System.out.println(s);
                S = s.split(":");
                if(S[0].equals(un) && S[1].equals(pwd)){
                	uid = Integer.parseInt(S[2]);
                }
                System.out.println(S[0] + S[1]);
                System.out.println(un + pwd);
                s = read.readLine();
            }
            r.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
		System.out.println(uid);
		return uid;
	}
	
	/**
	 * Finds and returns product object from inventory member array based on product id
	 * @precondition ID not null
	 * @postcondition return product with id ID or null if no product with id ID
	 * @param ID product id most likely from text field
	 * @return Product object or null
	 */
	public Product findProductById(int ID){
		Product P = null;
		for(int k = 0; k < inventory.size(); k++){
			if(inventory.get(k).id == ID){
				P = inventory.get(k);
			}
		}
		return P;
	}
	
	/**
	 * Finds and returns user object from users member array based on user id
	 * @precondition ID not null
	 * @postcondition return user with id ID or null if no user with id ID
	 * @param ID user id
	 * @return user object or null
	 */
	public User findUserById(int ID){
		User U = null;
		for(int k = 0; k < users.size(); k++){
			if(users.get(k).uid == ID){
				U = users.get(k);
			}
		}
		return U;
	}
	
	/**
	 * Populates 'users' arraylist with data from text file 'users.txt'
	 * @precondition 'users.txt' formatted properly
	 * @postcondition 'users' arraylist will be properly populated
	 */
	public void populateUsers(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("users.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            int j = 0;
            while(s != null && s != ""){
            	S = s.split(":");
            	users.add(new User(Integer.parseInt(S[0]), S[1], this));
            	System.out.println("outside " + s);
            	do  {
            		s = read.readLine();
            		System.out.println("inside " + s);
            		if(s.equals("break") == true){break;}
            		S = s.split(":");
            		users.get(j).shoppingCart.add(new Product(Integer.parseInt(S[0]), findProductById(Integer.parseInt(S[0])).type, Integer.parseInt(S[1]), findProductById(Integer.parseInt(S[0])).sellPrice));
            	}while(true);
            	s = read.readLine();
            	j++;
            }
            r.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	/**
	 * records current values of cost and revenue into 'crp.txt' to keep the values persistant
	 * @precondition cost and revenue values just changed
	 * @postcondition 'crp.txt' up to date
	 */
	public void rewritecrp(){
		try(FileWriter w = new FileWriter("crp.txt", false);
        	    BufferedWriter bw = new BufferedWriter(w);
        	    PrintWriter out = new PrintWriter(bw)){
			out.println(cost + ":" + revenue);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * Populates cost and revenue member variables with data from text file 'crp.txt'
	 * @precondition 'crp.txt' formatted properly, cost and revenue values not current with persistent data
	 * @postcondition cost and revenue member variables will be properly populated with persistant data
	 */
	public void loadcrp(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("crp.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            System.out.println(s);
            S = s.split(":");
            cost = Double.parseDouble(S[0]);
            revenue = Double.parseDouble(S[1]);
            r.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	/**
	 * Populates 'inventory' arraylist with data from text file 'inventory.txt'
	 * @precondition 'inventory.txt' formatted properly
	 * @postcondition 'inventory' arraylist will be properly populated
	 */
	public void loadInventory(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("inventory.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            String S6;
            while (s != null) {
                System.out.println(s);
                S = s.split(":");
                if(S.length < 7){
                	S6 = "";
                }else{
                	S6 = S[6];
                }
                inventory.add(new Product(Integer.parseInt(S[0]), S[1], Integer.parseInt(S[2]), Double.parseDouble(S[3]), Double.parseDouble(S[4]), S[5], S6, this));
                s = read.readLine();
            }
            r.close();
            for(int k = 0; k < inventory.size(); k++){
    			System.out.println(inventory.get(k).type + "\n"
    		+ "ID#: " + inventory.get(k).id + "\n"
    		+ "Quantity In Stock: " + inventory.get(k).quantity + "\n"
    		+ "Invoice Price: " + inventory.get(k).invoicePrice + "\n"
    		+ "Sell Price: " + inventory.get(k).sellPrice + "\n"
    		+ inventory.get(k).image);
    		}
 
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
}
