package views;
import java.awt.FlowLayout;
import java.awt.TextField;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;


/**
 * @author phil
 *this is the View template class that all of the view classes extend. It has easy simplified methods for placing components
 *and one abstract method makeView() to be written in the view subclass that is somewhat like a main method
 */
public abstract class View{
	JFrame F;
	Controller C;
	
	/**
	 * creates and returns a textfield with specified width and initial text
	 * @precondition none
	 * @postcondition returns a textfield with width numColumns and initial text text
	 * @param text the initial text for the text box
	 * @param numColumns the width of the textbox
	 * @return a textfield with width numColumns and initial text text
	 */
	public TextField createTextField(String text, int numColumns){
		TextField t = new TextField(text, numColumns);
		return t;
	}
	
	/**
	 * creates and returns a JButton with a label
	 * @precondition none
	 * @postcondition returns a new JButton with label label
	 * @param label the label to display for the button
	 * @return a new JButton with label label
	 */
	public JButton createJButton(String label){
		JButton t = new JButton(label);
		return t;
	}
	
	/**
	 * creates and returns a blank JLabel
	 * @precondition none
	 * @postcondition returns a blank JLabel
	 * @return a blank JLabel
	 */
	public JLabel createJLabel(){
		JLabel l = new JLabel();
		return l;
	}
	
	/**
	 * creates and returns a JLabel with text s
	 * @precondition none
	 * @postcondition returns a JLabel with text s
	 * @param s the text to display in the label
	 * @return a JLabel with text s
	 */
	public JLabel createJLabel(String s){
		JLabel l = new JLabel(s);
		return l;
	}
	
	/**
	 * creates and returns a JPanel with FlowLayout
	 * @precondition none
	 * @postcondition returns a new JPanel with FlowLayout set
	 * @return a new JPanel with FlowLayout set
	 */
	public JPanel createJPanel(){
		JPanel jp = new JPanel(new FlowLayout());
		return jp;
	}
	
	/**
	 * creates and returns a JLabel with icon I(mostly for placing an image)
	 * @precondition Icon must be set up with image
	 * @postcondition return a JLabel with Icon set to display an image
	 * @param I the Icon to be set in this label
	 * @return a JLabel with Icon set to display an image
	 */
	public JLabel createJLabel(Icon I){
		JLabel l = new JLabel(I);
		return l;
	}
	
	/**
	 * creates and returns an Icon with an image attached to it for use in a JLabel
	 * @precondition there is a image file at location specified by filepath
	 * @postcondition returns an Icon with attached image file
	 * @param filepath the filepath directly to an image file
	 * @return an Icon with attached image file
	 */
	public Icon createImageIcon(String filepath){
		ImageIcon ii = new ImageIcon(filepath);
		return ii;
	}
	
	/**
	 * this method is to be implemented to display the guis on the screen and handle the view kind of like a main method
	 * @precondition frame f is free to be used and it is the proper time for this view to be displayed
	 * @postcondition this view will be on the screen and fully functional ready to go
	 * @param f the frame to create the view in
	 */
	abstract void makeView(JFrame f);
	
	
}
