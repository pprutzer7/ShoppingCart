package views;

import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;
import models.Product;

/**
 * @author phil
 * this class is for the seller window graphical user interface, it also handles all button actions
 */
public class MerchantView extends View implements ActionListener{

	TextField t1, t2, t3;
	int button;
	
	/**
	 * initializes an object of type MerchantView with a pointer to the controller and an integer member
	 * variable button. There will be one object of type MerchantView made for each component that calls on actionPerformed
	 * each with a distinct number for the button variable. The actionPerformed method will be able to distinguish
	 * which component was used based on this number
	 * @param c a pointer to the controller for easy access
	 * @param b an integer to help distinguish which button was pushed
	 */
	public MerchantView(Controller c, int b){
		C = c;
		button = b;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 * this actionPerformed method handles all actions performed on all buttons in this view using different cases
	 * depending on what the button member variable value of the MerchantView instance that was attached to the listener
	 * was
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Product P = null;
		JFrame f;
		switch(this.button){
		case 1:
			try{
			System.out.println(this.t1.getText() + ",,," + this.t2.getText());
			P = C.findProductById(Integer.parseInt(this.t1.getText()));
			if(P == null){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID ID#, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			if(Double.parseDouble(this.t2.getText()) < 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT ENTER A NEGATIVE SELL PRICE");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			P.updateSellPrice(Double.parseDouble(this.t2.getText()));
			F.dispose();
			f = new JFrame();
			makeView(f);
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			break;
			
		case 2:try{
			for(int k = 0; k < C.inventory.size(); k++){
				if(Integer.toString(C.inventory.get(k).id).equals(this.t1.getText())){
					P = C.inventory.get(k);
				}
			}
			if(P == null){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID ID#, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			if(Integer.parseInt(this.t2.getText()) <= 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT ENTER A NEGATIVE OR ZERO QUANTITY");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			if(Double.parseDouble(this.t3.getText()) < 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT ENTER A NEGATIVE INVOICE PRICE");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			P.addQuantity(Integer.parseInt(this.t2.getText()), Double.parseDouble(this.t3.getText()));
		}catch(Exception e){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
			fail.add(failLabel);
			fail.pack();
			fail.setVisible(true);
			return;
		}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
			
		case 3:
			try{
			for(int k = 0; k < C.inventory.size(); k++){
				if(Integer.toString(C.inventory.get(k).id).equals(this.t1.getText())){
					P = C.inventory.get(k);
				}
			}
			if(P == null){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID ID#, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			if(Integer.parseInt(this.t2.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT REMOVE MORE ITEMS THAN ARE IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			if(Integer.parseInt(this.t2.getText()) <= 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT ENTER A NEGATIVE OR ZERO QUANTITY");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
			P.removeQuantity(Integer.parseInt(this.t2.getText()));
			
		}catch(Exception e){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
			fail.add(failLabel);
			fail.pack();
			fail.setVisible(true);
			return;
		}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 4:
			P = new Product(C.inventory.size()+1, this.t1.getText(), 0, 0, 0, "blank.jpg", this.t2.getText(), C);
			C.inventory.add(P);
			P.reWriteInventory();
			F.dispose();
			f = new JFrame();
			makeView(f);
			break;
		}
		
	}

	/* (non-Javadoc)
	 * @see views.View#makeView(javax.swing.JFrame)
	 */
	@Override
	void makeView(JFrame f) {
		F = f;
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setSize(800, 800);
		F.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.PAGE_START;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		//gbc.ipady = 100;
		
		JPanel crpView = new JPanel(new GridLayout(1, 2));
		crpView.add(createJLabel(""));
		JPanel crpPanel = new JPanel(new GridLayout(3, 1));
		crpPanel.add(createJLabel("COST: $" + String.format("%.2f",C.cost)));
		crpPanel.add(createJLabel("REVENUE: $" + String.format("%.2f",C.revenue)));
		crpPanel.add(createJLabel("PROFIT: $" + String.format("%.2f",C.profit)));
		crpView.add(crpPanel);
		F.add(crpView, gbc);
		JPanel inventoryView = createJPanel();
		JPanel[] inventoryCell = new JPanel[C.inventory.size()];
		inventoryView.setLayout(new GridLayout(3, (C.inventory.size()/3)+1));
		for(int k = 0; k < C.inventory.size(); k++){
			inventoryCell[k] = new JPanel(new GridLayout(5,1));
			inventoryCell[k].setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			inventoryCell[k].add(createJLabel(C.inventory.get(k).type));
			inventoryCell[k].add(createJLabel("ID#: " + C.inventory.get(k).id));
			inventoryCell[k].add(createJLabel("Quantity: " + C.inventory.get(k).quantity));
			inventoryCell[k].add(createJLabel("Invoice Price: $" + String.format("%.2f", C.inventory.get(k).invoicePrice)));
			inventoryCell[k].add(createJLabel("Sell Price: $" + String.format("%.2f", C.inventory.get(k).sellPrice)));
			inventoryView.add(inventoryCell[k]);
		}
		F.add(inventoryView, gbc);
		JPanel inputView = createJPanel();
		inputView.setLayout(new GridLayout(1, 3));
		JPanel a = createJPanel();
		a.setLayout(new GridLayout(4, 1));
		TextField sellPriceId = createTextField("Enter item ID#", 20);
		MerchantView udSellPrice = new MerchantView(C, 1);
		udSellPrice.t1 = sellPriceId;
		TextField newSellPrice = createTextField("Enter new sell price", 20);
		udSellPrice.t2 = newSellPrice;
		udSellPrice.F = F;
		JButton updateSellPrice = new JButton("Update sell price");
		updateSellPrice.addActionListener(udSellPrice);
		a.add(createJLabel(""));
		a.add(sellPriceId);
		a.add(newSellPrice);
		a.add(updateSellPrice);
		inputView.add(a);
		
		JPanel b = createJPanel();
		b.setLayout(new GridLayout(4, 1));
		TextField addQuantityId = createTextField("Enter item ID#", 20);
		MerchantView addQuantity = new MerchantView(C, 2);
		addQuantity.t1 = addQuantityId;
		TextField quantityAdded = createTextField("Enter number added", 20);
		addQuantity.t2 = quantityAdded;
		TextField newInvoicePrice = createTextField("Enter invoice price", 20);
		addQuantity.t3 = newInvoicePrice;
		addQuantity.F = F;
		JButton addProducts = new JButton("Add products");
		addProducts.addActionListener(addQuantity);
		b.add(addQuantityId);
		b.add(quantityAdded);
		b.add(newInvoicePrice);
		b.add(addProducts);
		inputView.add(b);
		
		JPanel c = createJPanel();
		c.setLayout(new GridLayout(4, 1));
		TextField removeQuantityId = createTextField("Enter item ID#", 20);
		MerchantView removeQuantity = new MerchantView(C, 3);
		removeQuantity.t1 = removeQuantityId;
		TextField quantityRemoved = createTextField("Enter number removed", 20);
		removeQuantity.t2 = quantityRemoved;
		removeQuantity.F = F;
		JButton removeProducts = new JButton("Remove products");
		removeProducts.addActionListener(removeQuantity);
		c.add(createJLabel(""));
		c.add(removeQuantityId);
		c.add(quantityRemoved);
		c.add(removeProducts, 3);
		inputView.add(c);
		JPanel addProduct = createJPanel();
		TextField type = createTextField("Enter name of new product", 30);
		TextField description = createTextField("Enter product description", 50);
		JButton newProduct = createJButton("Add a new product");
		MerchantView addNewProduct = new MerchantView(C, 4);
		addNewProduct.t1 = type;
		addNewProduct.t2 = description;
		addNewProduct.F = F;
		newProduct.addActionListener(addNewProduct);
		addProduct.add(type);
		addProduct.add(description);
		addProduct.add(newProduct);
		F.add(inputView, gbc);
		F.add(addProduct, gbc);
		
		
		F.pack();
		F.setVisible(true);
	}

}
