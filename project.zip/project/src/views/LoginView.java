package views;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;

import java.awt.GridBagConstraints;


/**
 * @author phil
 * this class is for the login window graphical user interface, it also handles all button actions
 */
public class LoginView extends View implements ActionListener{
	TextField username;
	TextField password;
	int button;
	JButton login;
	
	
	/**
	 * initializes an object of type LoginView with a pointer to the controller and an integer member
	 * variable button. There will be one object of type LoginView made for each component that calls on actionPerformed
	 * each with a distinct number for the button variable. The actionPerformed method will be able to distinguish
	 * which component was used based on this number
	 * @param c a pointer to the controller for easy access
	 * @param b an integer to help distinguish which button was pushed
	 */
	public LoginView(Controller c, int b){
		C = c;
		button = b;
	}
	
	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 * this actionPerformed method handles all actions performed on all buttons in this view using different cases
	 * depending on what the button member variable value of the LoginView instance that was attached to the listener
	 * was
	 */
	@Override
	public void actionPerformed(ActionEvent event) {
		switch(this.button){
		case 1:
			
			int uid = C.checkCredentials(username.getText(), password.getText());
			if(uid == 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("LOGIN FAILED, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
			}else{
				if(uid == 1000){
					MerchantView m = new MerchantView(C, 0);
					F.dispose();
					m.makeView(new JFrame());
				}else{
					C.ActiveUser = C.findUserById(uid);
					UserView u = new UserView(C, 0);
					F.dispose();
					u.makeView(new JFrame());
				}
			
			}
			break;
			
		case 2:
			System.out.println("button works");
			JFrame createUser = new JFrame();
			createUser.setSize(400, 400);
			createUser.setLayout(new GridBagLayout());
			GridBagConstraints gbc2 = new GridBagConstraints();
			gbc2.gridwidth = GridBagConstraints.REMAINDER;
			TextField t1 = createTextField("Choose username", 30);
			TextField t2 = createTextField("Choose Password", 30);
			createUser.add(t1, gbc2);
			createUser.add(t2, gbc2);
			login = createJButton("CONFIRM");
			LoginView newAcct = new LoginView(C, 3);
			newAcct.F = createUser;
			newAcct.username = t1;
			newAcct.password = t2;
			login.addActionListener(newAcct);
			createUser.add(login, gbc2);
			createUser.setPreferredSize(new Dimension(400, 200));
			createUser.pack();
			createUser.setVisible(true);
			
			break;
			
		case 3:
			System.out.println(username.getText() + " " + password.getText());
			if(username.getText().length() < 1 || password.getText().length() < 1){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("USERNAME AND/OR PASSWORD CANNOT BE BLANK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			if(C.checkCredentials(username.getText(), password.getText()) != 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("USERNAME/PASSWORD ALREADY EXISTS");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			int highestId = 1;
			for(int k = 0; k < C.users.size(); k++){
				if(C.users.get(k).uid > highestId){
					highestId = C.users.get(k).uid;
				}
			}
			highestId++;
			try(FileWriter w = new FileWriter("credentials.txt", true);
	        	    BufferedWriter bw = new BufferedWriter(w);
	        	    PrintWriter out = new PrintWriter(bw)){
					out.println(username.getText() + ":" + password.getText() + ":" + (highestId));
			} catch (IOException e) {
				e.printStackTrace();
			}
			try(FileWriter write = new FileWriter("users.txt", true);
	        	    BufferedWriter bwrite = new BufferedWriter(write);
	        	    PrintWriter o = new PrintWriter(bwrite)){
					o.println(highestId + ":" + username.getText());
					o.println("break");
			} catch (IOException e) {
				e.printStackTrace();
			}
			while(C.users.isEmpty() == false){
				C.users.remove(0);
			}
			C.populateUsers();
			F.dispose();
			break;
		}
	}
	
	/* (non-Javadoc)
	 * @see views.View#makeView(javax.swing.JFrame)
	 */
	public void makeView(JFrame f){
		F = f;
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setSize(800, 800);
		F.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		JLabel newUserLabel = createJLabel("New user?");
		JPanel newUserPanel = new JPanel(new GridLayout(1, 3));
		newUserPanel.add(createJLabel(""));
		newUserPanel.add(createJLabel(""));
		JPanel newUserCell = new JPanel(new GridBagLayout());
		JButton newUserButton = createJButton("Create a new account");
		LoginView newUserView = new LoginView(C, 2);
		newUserView.F = F;
		newUserButton.addActionListener(newUserView);
		newUserCell.add(newUserLabel, gbc);
		newUserCell.add(newUserButton, gbc);
		newUserPanel.add(newUserCell);
		F.add(newUserPanel, gbc);
		gbc.ipady = 200;
		JLabel Log_In = createJLabel("Please Log In");
		F.add(Log_In, gbc);
		gbc.ipady = GridBagConstraints.RELATIVE;
		username = createTextField("Username", 30);
		password = createTextField("Password", 30);
		F.add(username, gbc);
		F.add(password, gbc);
		gbc.ipady = 10;
		login = createJButton("CONFIRM");
		login.addActionListener(this);
		F.add(login, gbc);
		F.setPreferredSize(new Dimension(600, 400));
		F.pack();
		F.setVisible(true);
	}
	
}
