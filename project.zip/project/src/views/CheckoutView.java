package views;


import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;
import models.Product;



/**
 * @author phil
 * this class is for the checkout window graphical user interface, it also handles all button actions
 */
public class CheckoutView extends View implements ActionListener{
	TextField t1, t2, t3;
	int button;
	
	
	/**
	 * initializes an object of type CheckoutView with a pointer to the controller and an integer member
	 * variable button. There will be one object of type CheckoutView made for each component that calls on actionPerformed
	 * each with a distinct number for the button variable. The actionPerformed method will be able to distinguish
	 * which component was used based on this number
	 * @param c a pointer to the controller for easy access
	 * @param b an integer to help distinguish which button was pushed
	 */
	public CheckoutView(Controller c, int b){
		C = c;
		button = b;
	}


	/* (non-Javadoc)
	 * @see java.awt.event.ActionListener#actionPerformed(java.awt.event.ActionEvent)
	 * this actionPerformed method handles all actions performed on all buttons in this view using different cases
	 * depending on what the button member variable value of the CheckoutView instance that was attached to the listener
	 * was
	 */
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Product P = null;
		JFrame f;
		if(this.button >= 0 && this.button < 13){
			try{
				P = C.findProductById(C.ActiveUser.shoppingCart.get(this.button).id);
				if(Integer.parseInt(this.t1.getText()) > P.quantity){
					JFrame fail = new JFrame();
					fail.setLayout(new FlowLayout());
					JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
					fail.add(failLabel);
					fail.pack();
					fail.setVisible(true);
					return;
				}
				if(Integer.parseInt(this.t1.getText()) < 0){
					JFrame fail = new JFrame();
					fail.setLayout(new FlowLayout());
					JLabel failLabel = createJLabel("CANNOT ENTER A NEGATIVE QUANTITY");
					fail.add(failLabel);
					fail.pack();
					fail.setVisible(true);
					return;
				}
				C.ActiveUser.shoppingCart.get(this.button).quantity = Integer.parseInt(this.t1.getText());
				C.ActiveUser.reWriteUserFile();
				}catch(Exception e){
					JFrame fail = new JFrame();
					fail.setLayout(new FlowLayout());
					JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
					fail.add(failLabel);
					fail.pack();
					fail.setVisible(true);
					return;
				}
				F.dispose();
				f = new JFrame();
				makeView(f);
		}
		switch(this.button){
		
			
		case 13:
			
			if(t1.getText().length() == 16 && t2.getText().length() == 7 && t3.getText().length() == 3){
				for(int k = 0; k < C.ActiveUser.shoppingCart.size(); k++){
					C.findProductById(C.ActiveUser.shoppingCart.get(k).id).removeQuantity(C.ActiveUser.shoppingCart.get(k).quantity);
				}
			
				JFrame confirmPayment = new JFrame();
				confirmPayment.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
				confirmPayment.setLayout(new FlowLayout());
				JLabel confirmPaymentLabel = createJLabel("Thank you for shopping with us, your card has been charged $" + String.format("%.2f", C.ActiveUser.getCartPrice()));
				C.revenue += C.ActiveUser.getCartPrice();
				C.profit = C.revenue - C.cost;
				C.rewritecrp();
				confirmPayment.add(confirmPaymentLabel);
				confirmPayment.pack();
				confirmPayment.setVisible(true);
				C.ActiveUser.shoppingCart = new ArrayList<Product>();
				C.ActiveUser.reWriteUserFile();
				F.dispose();
			}else{
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("PLEASE RE ENTER CARD INFO, YOU HAVE MADE AN ERROR");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			
		}
	}


	/* (non-Javadoc)
	 * @see views.View#makeView(javax.swing.JFrame)
	 */
	@Override
	void makeView(JFrame f) {
		F = f;
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setSize(800, 800);
		F.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.PAGE_START;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		JPanel cartView = createJPanel();
		JPanel[] cartCell = new JPanel[C.ActiveUser.shoppingCart.size()];
		cartView.setLayout(new GridLayout(1, C.ActiveUser.shoppingCart.size()));
		JButton[] changeQty = new JButton[C.ActiveUser.shoppingCart.size()];
		CheckoutView[] buttonViews = new CheckoutView[C.ActiveUser.shoppingCart.size()];
		TextField[] newQty = new TextField[C.ActiveUser.shoppingCart.size()];
		for(int k = 0; k < C.ActiveUser.shoppingCart.size(); k++){
			cartCell[k] = new JPanel(new GridLayout(5,1));
			cartCell[k].setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			newQty[k] = createTextField("New quantity", 15);
			changeQty[k] = createJButton("Change quantity");
			buttonViews[k] = new CheckoutView(C, k);
			buttonViews[k].F = F;
			buttonViews[k].t1 = newQty[k];
			changeQty[k].addActionListener(buttonViews[k]);
			cartCell[k].add(createJLabel("Item: " + C.ActiveUser.shoppingCart.get(k).type));
			cartCell[k].add(createJLabel("Quantity: " + C.ActiveUser.shoppingCart.get(k).quantity));
			cartCell[k].add(createJLabel("Price: $" + String.format("%.2f", C.ActiveUser.shoppingCart.get(k).quantity*C.ActiveUser.shoppingCart.get(k).sellPrice)));
			cartCell[k].add(changeQty[k]);
			cartCell[k].add(newQty[k]);
			cartView.add(cartCell[k]);
			F.add(cartView, gbc);
		}
		TextField Number = createTextField("Enter your credit card number", 30);
		TextField expDate = createTextField("Expiration(mm/yyyy)", 20);
		TextField cvv = createTextField("cvv code", 10);
		gbc.ipady = 50;
		JPanel ccView = createJPanel();
		JPanel ccNumbers = createJPanel();
		ccNumbers.add(Number);
		ccNumbers.add(expDate);
		ccNumbers.add(cvv);
		ccView.setLayout(new GridBagLayout());
		ccView.add(ccNumbers, gbc);
		JButton pay = createJButton("Purchase Items");
		CheckoutView payView = new CheckoutView(C, 13);
		payView.F = F;
		payView.t1 = Number;
		payView.t2 = expDate;
		payView.t3 = cvv;
		pay.addActionListener(payView);
		ccView.add(pay);
		F.add(ccView);
		//F.setPreferredSize(new Dimension(600, 400));
		F.pack();
		F.setVisible(true);
	}
}
