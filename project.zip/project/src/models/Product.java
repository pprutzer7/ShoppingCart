package models;


import java.awt.FlowLayout;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import javax.swing.JFrame;
import javax.swing.JLabel;

import controllers.Controller;

/**
 * @author phil
 * This is the class for the model of type Product. It holds all of the information for a product being sold
 * by the seller
 */
public class Product {
	public int id;
	public String type;
	public int quantity;
	public double invoicePrice;
	public double sellPrice;
	Controller C;
	public String image;
	public String description;
	
	
	/**
	 * this is the constructor used to create Products for the inventory array
	 * these Products have all member variables initialized because the products
	 * in the inventory need all of their data
	 * @param i product id
	 * @param t product type(name)
	 * @param q quantity in stock
	 * @param ip invoice price (the price the items were each bought at by the seller)
	 * @param sp sale price
	 * @param img the image to display for this product
	 * @param d a short description of the Product
	 * @param c A reference to the Controller for easy access
	 */
	public Product(int i, String t, int q, double ip, double sp, String img, String d, Controller c){
		id = i;
		type = t;
		quantity = q;
		invoicePrice = ip;
		sellPrice = sp;
		image = img;
		C = c;
		description = d;
	}
	
	/**
	 * this is the constructor generally used to create product objects for placement into a users shopping cart
	 * for the purposes of the shopping cart the Product does not need all member variables initialized also
	 * the quantity field in these products refers to the quantity in the shopping cart
	 * @param i Product id number
	 * @param t Product type(name)
	 * @param q quantity in shopping cart
	 * @param sp sale price
	 */
	public Product(int i, String t, int q, double sp){
		id = i;
		type = t;
		quantity = q;
		sellPrice = sp;
	}
	

	/**
	 * this method updates the sellPrice field of the Product
	 * @precondition sp not null and a number
	 * @postcondition sets this Products sellPrice to sp and then updates the 'inventory.txt' file
	 * to keep persistance using the reWriteInventory() function
	 * @param sp the new sellPrice
	 */
	public void updateSellPrice(double sp) {
		sellPrice = sp;
		reWriteInventory();
	}

	/**
	 * this method adds quantity of the product to inventory
	 * @precondition q is an integer ip is a number
	 * @postcondition if q is less than or equal to zero a popup appears and method returns instantly doing nothing
	 * same thing if ip is less than zero. if q and ip are both proper it adds q to the quantity field, updates this products
	 * invoicePrice field to reflect the average of all quantity bought's invoice prices and rewrites
	 * 'inventory.txt', it also updates profit revenue and cost values and calls the rewriteCrp() function using
	 * this Products reference to the Controller C
	 * @param q quantity of product to add
	 * @param ip invoice price of this quantity
	 */
	public void addQuantity(int q, double ip) {
		if(q <= 0){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = new JLabel("CANNOT ENTER A NEGATIVE QUANTITY");
			fail.add(failLabel);
			fail.setAlwaysOnTop(true);
			fail.pack();
			fail.setVisible(true);
			return;
		}
		if(ip < 0){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = new JLabel("INVOICE PRICE CANNOT BE NEGATIVE");
			fail.add(failLabel);
			fail.setAlwaysOnTop(true);
			fail.pack();
			fail.setVisible(true);
			return;
		}
		C.cost += q*ip;
		C.profit = C.revenue - C.cost;
		C.rewritecrp();
		invoicePrice = (invoicePrice*quantity + ip*q)/(quantity + q);
		quantity = quantity + q;
		reWriteInventory();
	}
	
	/**
	 * this method removes a specified quantity of the product from inventory
	 * @precondition q must be an integer
	 * @postcondition if q is negative or zero a popup comes up and the method returns immediately doing nothing
	 * else if q is appropriate it updates this Products quantity value to reflect a certain number (q) of products 
	 * being removed the cost revenue and profit fields are updated as if this quantity was sold for the invoice price
	 * instead of just thrown in the garbage. 'crp.txt' and 'inventory.txt' are then rewritten to maintain persistency
	 * @param q the quantity of product to be removed
	 */
	public void removeQuantity(int q){
		if(q <= 0){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = new JLabel("CANNOT ENTER A NEGATIVE QUANTITY");
			fail.add(failLabel);
			fail.setAlwaysOnTop(true);
			fail.pack();
			fail.setVisible(true);
			return;
		}
		C.cost = C.cost - (q*invoicePrice);
		C.profit = C.revenue - C.cost;
		C.rewritecrp();
		quantity = quantity - q;
		reWriteInventory();
	}
	
	/**
	 * this method re writes the inventory.txt file
	 * @precondition the arraylist inventory of Products must be filled with the proper current contents of the inventory
	 * @postcondition inventory.txt will be wiped clean and rewritten to reflect the data in the inventory arraylist of products
	 */
	public void reWriteInventory(){
		try(FileWriter w = new FileWriter("inventory.txt", false);
        	    BufferedWriter bw = new BufferedWriter(w);
        	    PrintWriter out = new PrintWriter(bw)){
			for(int k = 0; k < C.inventory.size(); k++){
				out.println(C.inventory.get(k).id + ":" + C.inventory.get(k).type + ":" + C.inventory.get(k).quantity 
						+ ":" + C.inventory.get(k).invoicePrice + ":" + C.inventory.get(k).sellPrice
						+ ":" + C.inventory.get(k).image + ":" + C.inventory.get(k).description);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
