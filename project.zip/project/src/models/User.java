package models;


import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import controllers.Controller;

/**
 * @author phil
 * This is the User class, objects of this class are used to represent customer users mainly for the purpose
 * of managing their shopping cart. The shopping cart is represented as an arraylist of Product objects
 */
public class User {
	public ArrayList<Product> shoppingCart;
	public int uid;
	Controller C;
	public String username;
	
	/**
	 * this i the constructor for User objects, it sets the three member variables uid, username and C
	 * and then it initializes the shopping cart arraylist
	 * @param ID user id
	 * @param un user name
	 * @param c a reference to the Controller for easy access
	 */
	public User(int ID, String un, Controller c){
		uid = ID;
		username = un;
		C = c;
		shoppingCart = new ArrayList<Product>();
	}
	
	/**
	 * this method returns the total number of items in the shopping cart, accounting for multiples of the same
	 * type using the quantity field
	 * @precondition the shopping cart must be initialized
	 * @postcondition return the total number of individual items in this Users shopping cart
	 * @return the sum of the quantity values for all products in this Users shopping cart
	 */
	public int getNumItemsInCart(){
		int result = 0;
		for(int k = 0; k < shoppingCart.size(); k++){
			result += shoppingCart.get(k).quantity;
		}
		return result;
	}
	
	/**
	 * this method returns the total price of all items in the shopping cart, accounting for multiples of the same
	 * type using the quantity field
	 * @precondition the shopping cart must be initialized
	 * @postcondition return the total price of all items in this Users shopping cart
	 * @return the sum of the quantity values for all products in this Users shopping cart multiplied by the sellprice for each
	 */
	public double getCartPrice(){
		double result = 0;
		for(int k = 0; k < shoppingCart.size(); k++){
			result += (shoppingCart.get(k).quantity * shoppingCart.get(k).sellPrice);
		}
		return result;
	}
	
	/**
	 * this method rewrites the users.txt file in order to keep the data persistent everytime the activeusers
	 * shopping cart is updated
	 * @precondition all data in the users arraylist is current
	 * @postcondition users.txt is wiped clean and rewritten with the current data in the users arraylist
	 */
	public void reWriteUserFile(){
		System.out.println("rewriting users.txt " + C.users.size());
		try(FileWriter U = new FileWriter("users.txt", false);
        	    BufferedWriter bw = new BufferedWriter(U);
        	    PrintWriter out = new PrintWriter(bw)){
			for(int k = 0; k < C.users.size(); k++){
				System.out.println(C.users.get(k).uid + ":" + C.users.get(k).username);
				out.println(C.users.get(k).uid + ":" + C.users.get(k).username);
				for(int j = 0; j < C.users.get(k).shoppingCart.size(); j++){
					System.out.println(C.users.get(k).shoppingCart.get(j).id + ":" + C.users.get(k).shoppingCart.get(j).quantity);
					out.println(C.users.get(k).shoppingCart.get(j).id + ":" + C.users.get(k).shoppingCart.get(j).quantity);
				}
				out.println("break");
				System.out.println("break");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
