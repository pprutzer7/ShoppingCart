
import javax.swing.JFrame;

import controllers.Controller;

import views.LoginView;

public class Main {

	static Controller cont;
	static JFrame f;
	
	public static void main(String args[]){
		cont = new Controller();
		cont.loadInventory();
		cont.populateUsers();
		cont.loadcrp();
		cont.profit = cont.revenue - cont.cost;
		LoginView v = new LoginView(cont, 1);
		f = new JFrame();
		v.makeView(f);
	}
}
