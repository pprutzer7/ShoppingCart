
public class Main {

	
	/*
	package BarGraph;

	import java.awt.FlowLayout;
	import java.awt.GridLayout;
	import java.awt.TextField;
	import java.awt.event.KeyEvent;
	import java.awt.event.KeyListener;

	import javax.swing.*;

	public class BarGraph {
		
		static JFrame f;
		static Bar1 b1 = null;
		static Bar2 b2 = null;
		static Bar3 b3 = null;
		static Bar4 b4 = null;
		static Data d = null;
		
		public static TextField createTextField(String s, int bb) {
			final int b = bb;
			final TextField t = new TextField(s);
			t.addKeyListener(new KeyListener() {
				public void keyPressed(KeyEvent event) {
					return;
				}
				
				public void keyTyped(KeyEvent event) {
					return;
				}
				public void keyReleased(KeyEvent event) {
					try{
						switch(b){
						case 1:
							d.w1 = Integer.parseInt(t.getText());
							break;
						case 2:
							d.w2 = Integer.parseInt(t.getText());
							break;
						case 3:
							d.w3 = Integer.parseInt(t.getText());
							break;
						case 4:
							d.w4 = Integer.parseInt(t.getText());
							break;
						}
						f.repaint();
						}catch(Exception e){
							
						}
					return;
				}
			});
			return t;
		}
		
		public static void main(String[] args) {
			d = new Data();
			f = new JFrame();
			//f.pack();
			f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			//f.setVisible(true);
			f.setSize(650, 450);
			f.setLayout(new FlowLayout());
			b1 = new Bar1(d);
			b2 = new Bar2(d);
			b3 = new Bar3(d);
			b4 = new Bar4(d);
			JPanel p1, p2;
			p1 = new JPanel();
			p2 = new JPanel();
			p1.setVisible(true);
			p2.setVisible(true);
			p1.setSize(200, 400);
			p2.setSize(400, 400);
			p1.setLayout(new GridLayout(4,1));
			p2.setLayout(new GridLayout(4,1));
			
			JLabel lb1, lb2, lb3, lb4;
			lb1 = new JLabel(b1, SwingConstants.LEFT);
			lb2 = new JLabel(b2, SwingConstants.LEFT);
			lb3 = new JLabel(b3, SwingConstants.LEFT);
			lb4 = new JLabel(b4, SwingConstants.LEFT);
			p2.add(lb1);
			p2.add(lb2);
			p2.add(lb3);
			p2.add(lb4);
			TextField[] jtfs = new TextField[4];
			for (int i = 1; i < 5; i++) {
				jtfs[i - 1] = createTextField("Enter a width for bar " + i, i);
				p1.add(jtfs[i - 1]);
			}
			f.add(p1);
			f.add(p2);
			f.pack();
			f.setVisible(true);
		}

	}

	
	*/
	
}
