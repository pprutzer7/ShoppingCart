
public class User {
	private ShoppingCart cart;

}
