
public class Controller {
	
	
	
	//coontains methods for updating all data in models that is changed through action in views
	
	public void updateModelData1(Model m){
		
	}
	
	public void updateModelData2(Model m){
		
	}

	public void updateModelData3(Model m){
	
	}
}
