import javax.swing.JComponent;
import javax.swing.JFrame;


public abstract class View extends JComponent{

	
}
