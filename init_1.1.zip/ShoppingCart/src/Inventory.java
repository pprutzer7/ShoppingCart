
public class Inventory {

}
