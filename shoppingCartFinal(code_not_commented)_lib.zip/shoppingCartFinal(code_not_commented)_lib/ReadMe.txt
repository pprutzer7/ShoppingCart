merchant username is: merchant
merchant password is: merch777

If you would like to log in as a user you
can create a login on the home page

There are a few ways that you can accidentally
buy more products than are in inventory. This will
not break the code it will just set the quantity 
available to a negative number and all the numbers
will get screwed up. It should be pretty hard to do
this unless you are intentionally trying to break it
though.