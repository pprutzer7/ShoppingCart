package models;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

import controllers.Controller;

public class Product {
	public int id;
	public String type;
	public int quantity;
	public double invoicePrice;
	public double sellPrice;
	Controller C;
	public String image;
	public String description;
	
	
	public Product(int i, String t, int q, double ip, double sp, String img, String d, Controller c){
		id = i;
		type = t;
		quantity = q;
		invoicePrice = ip;
		sellPrice = sp;
		image = img;
		C = c;
		description = d;
	}
	
	public Product(int i, String t, int q, double sp){
		id = i;
		type = t;
		quantity = q;
		sellPrice = sp;
	}
	

	public void updateSellPrice(double sp) {
		sellPrice = sp;
		reWriteInventory();
	}

	public void addQuantity(int q, double ip) {
		C.cost += q*ip;
		C.profit = C.revenue - C.cost;
		C.rewritecrp();
		invoicePrice = (invoicePrice*quantity + ip*q)/(quantity + q);
		quantity = quantity + q;
		reWriteInventory();
	}
	
	public void removeQuantity(int q){
		C.cost = C.cost - (q*invoicePrice);
		C.profit = C.revenue - C.cost;
		C.rewritecrp();
		quantity = quantity - q;
		reWriteInventory();
	}
	
	private void reWriteInventory(){
		try(FileWriter w = new FileWriter("inventory.txt", false);
        	    BufferedWriter bw = new BufferedWriter(w);
        	    PrintWriter out = new PrintWriter(bw)){
			for(int k = 0; k < C.inventory.size(); k++){
				out.println(C.inventory.get(k).id + ":" + C.inventory.get(k).type + ":" + C.inventory.get(k).quantity 
						+ ":" + C.inventory.get(k).invoicePrice + ":" + C.inventory.get(k).sellPrice
						+ ":" + C.inventory.get(k).image + ":" + C.inventory.get(k).description);
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
