package models;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import controllers.Controller;

public class User {
	public ArrayList<Product> shoppingCart;
	public int uid;
	Controller C;
	public String username;
	
	public User(int ID, String un, Controller c){
		uid = ID;
		username = un;
		C = c;
		shoppingCart = new ArrayList<Product>();
	}
	
	public int getNumItemsInCart(){
		int result = 0;
		for(int k = 0; k < shoppingCart.size(); k++){
			result += shoppingCart.get(k).quantity;
		}
		return result;
	}
	
	public double getCartPrice(){
		double result = 0;
		for(int k = 0; k < shoppingCart.size(); k++){
			result += (shoppingCart.get(k).quantity * shoppingCart.get(k).sellPrice);
		}
		return result;
	}
	
	public void reWriteUserFile(){
		System.out.println("rewriting users.txt " + C.users.size());
		try(FileWriter U = new FileWriter("users.txt", false);
        	    BufferedWriter bw = new BufferedWriter(U);
        	    PrintWriter out = new PrintWriter(bw)){
			for(int k = 0; k < C.users.size(); k++){
				System.out.println(C.users.get(k).uid + ":" + C.users.get(k).username);
				out.println(C.users.get(k).uid + ":" + C.users.get(k).username);
				for(int j = 0; j < C.users.get(k).shoppingCart.size(); j++){
					System.out.println(C.users.get(k).shoppingCart.get(j).id + ":" + C.users.get(k).shoppingCart.get(j).quantity);
					out.println(C.users.get(k).shoppingCart.get(j).id + ":" + C.users.get(k).shoppingCart.get(j).quantity);
				}
				out.println("break");
				System.out.println("break");
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
