package controllers;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import models.Product;
import models.User;

public class Controller {
	
	public ArrayList<Product> inventory;
	public ArrayList<User> users;
	public User ActiveUser;
	public double cost;
	public double revenue;
	public double profit;
	
	public Controller(){
		inventory = new ArrayList<Product>();
		users = new ArrayList<User>();
	}
	
	public int checkCredentials(String un, String pwd){
		int uid = 0;
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("credentials.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            while (s != null) {
                System.out.println(s);
                S = s.split(":");
                if(S[0].equals(un) && S[1].equals(pwd)){
                	uid = Integer.parseInt(S[2]);
                }
                System.out.println(S[0] + S[1]);
                System.out.println(un + pwd);
                s = read.readLine();
            }
            r.close();
 
        } catch (IOException e) {
            e.printStackTrace();
        }
		System.out.println(uid);
		return uid;
	}
	
	public Product findProductById(int ID){
		Product P = null;
		for(int k = 0; k < inventory.size(); k++){
			if(inventory.get(k).id == ID){
				P = inventory.get(k);
			}
		}
		return P;
	}
	
	public User findUserById(int ID){
		User U = null;
		for(int k = 0; k < users.size(); k++){
			if(users.get(k).uid == ID){
				U = users.get(k);
			}
		}
		return U;
	}
	
	public void populateUsers(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("users.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            int j = 0;
            while(s != null && s != ""){
            	S = s.split(":");
            	users.add(new User(Integer.parseInt(S[0]), S[1], this));
            	System.out.println("outside " + s);
            	do  {
            		s = read.readLine();
            		System.out.println("inside " + s);
            		if(s.equals("break") == true){break;}
            		S = s.split(":");
            		users.get(j).shoppingCart.add(new Product(Integer.parseInt(S[0]), findProductById(Integer.parseInt(S[0])).type, Integer.parseInt(S[1]), findProductById(Integer.parseInt(S[0])).sellPrice));
            	}while(true);
            	s = read.readLine();
            	j++;
            }
            r.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public void rewritecrp(){
		try(FileWriter w = new FileWriter("crp.txt", false);
        	    BufferedWriter bw = new BufferedWriter(w);
        	    PrintWriter out = new PrintWriter(bw)){
			out.println(cost + ":" + revenue);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public void loadcrp(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("crp.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            System.out.println(s);
            S = s.split(":");
            cost = Double.parseDouble(S[0]);
            revenue = Double.parseDouble(S[1]);
            r.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	public void loadInventory(){
		BufferedReader read = null;
		try {
            FileReader r = new FileReader("inventory.txt");
            read = new BufferedReader(r);
            String s = read.readLine();
            String[] S;
            while (s != null) {
                System.out.println(s);
                S = s.split(":");
                inventory.add(new Product(Integer.parseInt(S[0]), S[1], Integer.parseInt(S[2]), Double.parseDouble(S[3]), Double.parseDouble(S[4]), S[5], S[6], this));
                s = read.readLine();
            }
            r.close();
            for(int k = 0; k < inventory.size(); k++){
    			System.out.println(inventory.get(k).type + "\n"
    		+ "ID#: " + inventory.get(k).id + "\n"
    		+ "Quantity In Stock: " + inventory.get(k).quantity + "\n"
    		+ "Invoice Price: " + inventory.get(k).invoicePrice + "\n"
    		+ "Sell Price: " + inventory.get(k).sellPrice + "\n"
    		+ inventory.get(k).image);
    		}
 
        } catch (IOException e) {
            e.printStackTrace();
        }
	}
	
	//coontains methods for updating all data in models that is changed through action in views
	
	/*public void updateModelData1(Model m){
		
	}
	
	public void updateModelData2(Model m){
		
	}

	public void updateModelData3(Model m){
	
	}*/
}
