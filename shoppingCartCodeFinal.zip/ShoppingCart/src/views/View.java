package views;
import java.awt.FlowLayout;
import java.awt.TextField;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;


public abstract class View{
	JFrame F;
	Controller C;
	public TextField createTextField(String text, int numColumns){
		TextField t = new TextField(text, numColumns);
		return t;
	}
	
	public JButton createJButton(String label){
		JButton t = new JButton(label);
		return t;
	}
	
	public JLabel createJLabel(){
		JLabel l = new JLabel();
		return l;
	}
	
	public JLabel createJLabel(String s){
		JLabel l = new JLabel(s);
		return l;
	}
	
	public JPanel createJPanel(){
		JPanel jp = new JPanel(new FlowLayout());
		return jp;
	}
	
	public JLabel createJLabel(Icon I){
		JLabel l = new JLabel(I);
		return l;
	}
	
	public Icon createImageIcon(String filepath){
		ImageIcon ii = new ImageIcon(filepath);
		return ii;
	}
	
	abstract void makeView(JFrame f);
	
	
}
