package views;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.TextField;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import controllers.Controller;
import models.Product;

public class UserView extends View implements ActionListener{
	TextField t1, t2, t3;
	int button;
	
	
	public UserView(Controller c, int b){
		C = c;
		button = b;
	}
	
	@Override
	public void actionPerformed(ActionEvent arg0) {
		Product P = null;
		JFrame f;
		JLabel descriptionLabel;
		JFrame description;
		switch(this.button){
		case 1:try{
			if(C.ActiveUser.getNumItemsInCart() == 0){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("YOUR CART IS EMPTY, YOU CANNOT CHECKOUT WITH AN EMPTY CART");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
		}catch(Exception e){
			JFrame fail = new JFrame();
			fail.setLayout(new FlowLayout());
			JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
			fail.add(failLabel);
			fail.pack();
			fail.setVisible(true);
			return;
		}
			F.dispose();
			f = new JFrame();
			CheckoutView cv = new CheckoutView(C, 0);
			cv.makeView(f);
			break;
			
		case 2:
			C.ActiveUser.shoppingCart = new ArrayList<Product>();
			C.ActiveUser.reWriteUserFile();
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
			
		case 3:
			try{
			for(int k = 0; k < C.inventory.size(); k++){
				if(Integer.toString(C.inventory.get(k).id).equals(this.t1.getText())){
					P = C.inventory.get(k);
				}
			}
			
			if(P == null){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID ID#, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			if(Integer.parseInt(this.t2.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("CANNOT REMOVE MORE ITEMS THAN ARE IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			P.removeQuantity(Integer.parseInt(this.t2.getText()));
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 4:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 5:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 6:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 7:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 8:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 9:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 10:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 11:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 12:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 13:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 14:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 15:
			try{
			P = C.findProductById(this.button - 3);
			if(Integer.parseInt(this.t1.getText()) > P.quantity){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("NOT ENOUGH IN STOCK");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			C.ActiveUser.shoppingCart.add(new Product(P.id, P.type, Integer.parseInt(this.t1.getText()), P.sellPrice));
			C.ActiveUser.reWriteUserFile();
			}catch(Exception e){
				JFrame fail = new JFrame();
				fail.setLayout(new FlowLayout());
				JLabel failLabel = createJLabel("INVALID INPUT TYPE, PLEASE TRY AGAIN");
				fail.add(failLabel);
				fail.pack();
				fail.setVisible(true);
				return;
			}
			F.dispose();
			f = new JFrame();
			makeView(f);
			
			break;
		case 16:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 17:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 18:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 19:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 20:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 21:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
		case 22:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 23:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 24:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 25:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 26:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		case 27:
			P = C.findProductById(this.button - 15);
			description = new JFrame();
			description.setLayout(new FlowLayout());
			descriptionLabel = createJLabel(P.description);
			description.add(descriptionLabel);
			description.pack();
			description.setVisible(true);
			break;
		}
		
	}

	@Override
	void makeView(JFrame f) {
		F = f;
		F.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		F.setSize(800, 800);
		F.setLayout(new GridBagLayout());
		GridBagConstraints gbc = new GridBagConstraints();
		gbc.anchor = GridBagConstraints.PAGE_START;
		gbc.gridwidth = GridBagConstraints.REMAINDER;
		//gbc.ipady = 100;
		JPanel cartView = createJPanel();
		cartView.setLayout(new GridLayout(1, 2));
		cartView.add(createJLabel(""));
		JPanel cartCell = createJPanel();
		cartCell.setLayout(new GridBagLayout());
		cartCell.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		cartCell.add(createJLabel("Logged in as: " + C.ActiveUser.username), gbc);
		cartCell.add(createJLabel("# of items in cart: " + C.ActiveUser.getNumItemsInCart()), gbc);
		cartCell.add(createJLabel("Price of items in cart: $" + String.format("%.2f", C.ActiveUser.getCartPrice())), gbc);
		JPanel cartButtons = new JPanel(new GridLayout(1, 2));
		JButton checkout = createJButton("Proceed to checkout");
		UserView checkoutView = new UserView(C, 1);
		checkoutView.F = F;
		checkout.addActionListener(checkoutView);
		cartButtons.add(checkout);
		JButton clearCart = createJButton("Clear contents of shopping cart");
		UserView clearCartView = new UserView(C, 2);
		clearCartView.F = F;
		clearCart.addActionListener(clearCartView);
		cartButtons.add(clearCart);
		cartCell.add(cartButtons);
		cartView.add(cartCell);
		F.add(cartView, gbc);
		JPanel productView = createJPanel();
		JPanel[] productCell = new JPanel[C.inventory.size()];
		JButton[] addToCart = new JButton[C.inventory.size()];
		JButton[] getDescription = new JButton[C.inventory.size()];
		TextField[] qtyToAdd = new TextField[C.inventory.size()];
		UserView[] buttonViews = new UserView[C.inventory.size()];
		UserView[] gdButtonViews = new UserView[C.inventory.size()];
		productView.setLayout(new GridLayout(2, C.inventory.size()/2));
		for(int k = 0; k < C.inventory.size(); k++){
			productCell[k] = new JPanel(new GridBagLayout());
			qtyToAdd[k] = createTextField("Qty to add", 10);
			addToCart[k] = createJButton("Add to cart");
			getDescription[k] = createJButton("View item description");
			buttonViews[k] = new UserView(C, k+4);
			buttonViews[k].F = F;
			gdButtonViews[k] = new UserView(C, k+16);
			gdButtonViews[k].F = F;
			buttonViews[k].t1 = qtyToAdd[k];
			addToCart[k].addActionListener(buttonViews[k]);
			getDescription[k].addActionListener(gdButtonViews[k]);
			productCell[k].setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
			productCell[k].add(createJLabel(new ImageIcon(C.inventory.get(k).image)), gbc);
			productCell[k].add(createJLabel(C.inventory.get(k).type), gbc);
			productCell[k].add(createJLabel("# in stock: " + C.inventory.get(k).quantity), gbc);
			productCell[k].add(createJLabel("Price: $" + String.format("%.2f", C.inventory.get(k).sellPrice)), gbc);
			productCell[k].add(getDescription[k], gbc);
			productCell[k].add(addToCart[k], gbc);
			productCell[k].add(qtyToAdd[k], gbc);
			productView.add(productCell[k]);
		}
		F.add(productView, gbc);
		
		F.pack();
		F.setVisible(true);
	}
}
